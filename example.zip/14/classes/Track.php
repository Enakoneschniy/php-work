<?php

final class Track extends Auto {

}