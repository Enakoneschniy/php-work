<?php
echo "<h1>Hello World</h1>";

$name = "Петя";
$user_name = 'Меня зовут: $name';
$user_Name = 'admin';

//$вася = "Вася";//так не писать

?>

<span>Меня зовут: <strong><?=$name?></strong></span>
