<?php

class Dog implements IAnimal{
    public function say(){
        echo 'Woof Woof<br>';
    }
}