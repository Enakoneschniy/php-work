<?php

interface IAnimal {
    public function say();
}