<?php

class Cat implements IAnimal{
    public function say(){
        echo 'Meow Meow<br>';
    }
}