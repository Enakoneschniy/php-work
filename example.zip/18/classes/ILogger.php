<?php

interface ILogger {
    public function log($message);
}